plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.nicolas_bruna"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.nicolas_bruna"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true // Mantienes Compose features, lo que es bueno si planeas usarlo.
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose) // Relacionado con Compose
    implementation(platform(libs.androidx.compose.bom)) // BOM para Compose
    implementation(libs.androidx.ui) // Compose UI
    implementation(libs.androidx.ui.graphics) // Compose Graphics
    implementation(libs.androidx.ui.tooling.preview) // Compose Tooling Preview
    implementation(libs.androidx.material3) // Para Componentes Material 3 en Compose (androidx.compose.material3:material3)

    implementation(libs.google.material)    // Para Temas XML y Componentes View de Material (com.google.android.material:material)

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom)) // BOM de Compose para pruebas
    androidTestImplementation(libs.androidx.ui.test.junit4) // Pruebas de UI de Compose
    debugImplementation(libs.androidx.ui.tooling) // Compose Tooling
    debugImplementation(libs.androidx.ui.test.manifest) // Manifiesto de pruebas de Compose
}

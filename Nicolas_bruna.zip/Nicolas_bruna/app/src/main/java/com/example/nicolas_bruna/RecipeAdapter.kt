package com.example.nicolas_bruna

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
// Importar Glide si decides usarlo para imágenes desde URL
// import com.bumptech.glide.Glide

class RecipeAdapter(
    private val recipes: List<Recipe>,
    private val onItemClick: (Recipe) -> Unit // Lambda para manejar clics en los ítems
) : RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder>() {

    inner class RecipeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // IDs actualizados para coincidir con el item_recipe_card.xml actual
        val recipeImage: ImageView = itemView.findViewById(R.id.imageView_recipe_item)
        val recipeName: TextView = itemView.findViewById(R.id.textView_recipe_name_item)
        val recipeTime: TextView = itemView.findViewById(R.id.textView_recipe_time_item)
        // Las vistas para category y servings han sido eliminadas ya que no están en el XML

        fun bind(recipe: Recipe) {
            recipeName.text = recipe.name
            // El item_recipe_card.xml ya tiene "Tiempo: " en el tools:text,
            // pero el dato 'recipe.time' es solo "20 min".
            // Si quieres que el "Tiempo: " se muestre dinámicamente:
            recipeTime.text = "Tiempo: ${recipe.time}"
            // Si prefieres que el XML maneje el prefijo "Tiempo: " y solo mostrar el valor:
            // recipeTime.text = recipe.time


            // Cargar imagen
            if (recipe.imageResId != null) {
                recipeImage.setImageResource(recipe.imageResId)
            } else if (recipe.imageUrl != null) {
                // Glide.with(itemView.context).load(recipe.imageUrl).into(recipeImage)
                recipeImage.setImageResource(R.drawable.ic_launcher_background) // Placeholder
            } else {
                recipeImage.setImageResource(R.drawable.ic_launcher_background) // Placeholder
            }

            itemView.setOnClickListener {
                onItemClick(recipe)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recipe_card, parent, false)
        return RecipeViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecipeViewHolder, position: Int) {
        val recipe = recipes[position]
        holder.bind(recipe)
    }

    override fun getItemCount() = recipes.size
}


package com.example.nicolas_bruna

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.nicolas_bruna.ui.theme.Nicolas_brunaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Habilitar edge-to-edge primero

        // Establecer el contenido desde el layout XML
        setContentView(R.layout.activity_main) // Referencia a R

        // Obtener referencias a los botones del layout XML
        val buttonBreakfasts = findViewById<Button>(R.id.button_category_breakfasts) // Referencia a R
        buttonBreakfasts.setOnClickListener {
            val intent = Intent(this, RecipeListActivity::class.java)
            // Opcional: pasar datos, como la categoría seleccionada
            // intent.putExtra("CATEGORY_NAME", "Desayunos")
            startActivity(intent)
        }

        val buttonLunches = findViewById<Button>(R.id.button_category_lunches) // Referencia a R
        buttonLunches.setOnClickListener {
            val intent = Intent(this, RecipeListActivity::class.java)
            // intent.putExtra("CATEGORY_NAME", "Almuerzos")
            startActivity(intent)
        }

        val buttonDinners = findViewById<Button>(R.id.button_category_dinners) // Referencia a R
        buttonDinners.setOnClickListener {
            val intent = Intent(this, RecipeListActivity::class.java)
            // intent.putExtra("CATEGORY_NAME", "Cenas")
            startActivity(intent)
        }

        val buttonDesserts = findViewById<Button>(R.id.button_category_desserts) // Referencia a R
        buttonDesserts.setOnClickListener {
            val intent = Intent(this, RecipeListActivity::class.java)
            // intent.putExtra("CATEGORY_NAME", "Postres")
            startActivity(intent)
        }

        // Si MainActivity va a ser principalmente XML, esta sección de Compose
        // que reemplaza todo el contenido debería ser eliminada o repensada.
        // Por ahora, la comento para que el XML funcione.
        /*
        setContent {
            Nicolas_brunaTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
        */
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Nicolas_brunaTheme {
        Greeting("Android")
    }
}

package com.example.nicolas_bruna

data class Recipe(
    val id: String, // Un identificador único para la receta
    val name: String,
    val category: String, // Ej: "Desayunos", "Almuerzos", etc.
    val time: String, // Ej: "30 min"
    val servings: String, // Ej: "2 porciones"
    val ingredients: List<String>,
    val preparationSteps: List<String>,
    val imageUrl: String? = null, // URL de la imagen (opcional)
    val imageResId: Int? = null // ID de recurso drawable para la imagen (opcional)
)

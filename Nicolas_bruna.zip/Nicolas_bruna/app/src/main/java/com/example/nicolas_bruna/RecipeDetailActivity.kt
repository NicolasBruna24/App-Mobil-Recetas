package com.example.nicolas_bruna

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
// import com.bumptech.glide.Glide // Glide no está siendo usado aún

class RecipeDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_detail)

        // Recuperar el ID de la receta (si se pasó alguno)
        // val recipeId = intent.getStringExtra("RECIPE_ID") // Aún no pasamos esto

        // Simulación: Configurar datos de ejemplo directamente
        // En una app real, cargarías los datos basados en recipeId
        val recipeNameTextView = findViewById<TextView>(R.id.textView_recipe_name_detail)
        val recipeTimeTextView = findViewById<TextView>(R.id.textView_recipe_time_detail)
        val recipeServingsTextView = findViewById<TextView>(R.id.textView_recipe_servings_detail)
        val ingredientsListTextView = findViewById<TextView>(R.id.textView_ingredients_list)
        val preparationStepsTextView = findViewById<TextView>(R.id.textView_preparation_steps)
        val recipeImageView = findViewById<ImageView>(R.id.imageView_recipe_detail_main)

        recipeNameTextView.text = "Nombre de Receta Detallado (Ejemplo)"
        recipeTimeTextView.text = "45 min"
        recipeServingsTextView.text = "2 porciones"
        ingredientsListTextView.text = "- Ingrediente 1\n- Ingrediente 2\n- Ingrediente 3"
        preparationStepsTextView.text = "1. Paso uno de la preparación.\n2. Paso dos de la preparación."

        // Ejemplo de cómo cargar una imagen (necesitarás una URL o recurso drawable)
        // Por ahora, usamos un placeholder si tienes uno, o el srcCompat de tools
        recipeImageView.setImageResource(R.drawable.ic_launcher_background) // Placeholder de ejemplo

        // Si usaras Glide para cargar desde una URL:
        // val imageUrl = "URL_DE_LA_IMAGEN_DE_LA_RECETA"
        // Glide.with(this).load(imageUrl).into(recipeImageView)

        // Configurar el botón de "volver" en la ActionBar (si tu tema tiene una)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        // El título de la ActionBar se puede establecer aquí o en el Manifest
        // supportActionBar?.title = "Detalle de la Receta"
    }

    // Para manejar el clic en el botón de "volver" de la ActionBar
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

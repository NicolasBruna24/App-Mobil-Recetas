package com.example.nicolas_bruna

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button // Mantendremos este botón temporal por ahora
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class RecipeListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var recipeAdapter: RecipeAdapter
    private var sampleRecipes: MutableList<Recipe> = mutableListOf() // Lista para los datos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_list)

        // Configurar RecyclerView
        recyclerView = findViewById(R.id.recyclerView_recipes)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Cargar datos de ejemplo (o los que correspondan a la categoría)
        loadSampleRecipes() // Método para cargar/crear recetas de ejemplo

        // Inicializar y asignar el adaptador
        recipeAdapter = RecipeAdapter(sampleRecipes) { recipe ->
            // Acción al hacer clic en una receta: navegar a RecipeDetailActivity
            val intent = Intent(this, RecipeDetailActivity::class.java)
            // Aquí pasarías el ID de la receta u otros datos necesarios para el detalle
            intent.putExtra("RECIPE_ID", recipe.id)
            // También podrías pasar el nombre de la receta para mostrarlo como título, por ejemplo
            intent.putExtra("RECIPE_NAME", recipe.name)
            startActivity(intent)
        }
        recyclerView.adapter = recipeAdapter

        // --- Botón temporal (puedes eliminarlo si lo deseas) ---
        val navigateToDetailButton = findViewById<Button>(R.id.button_navigate_to_detail_temp)
        navigateToDetailButton.setOnClickListener {
            // Este botón ahora podría ser redundante si la lista funciona,
            // o podrías usarlo para probar RecipeDetailActivity con un ID específico.
            // Por ahora, lo dejamos para que no cause error, pero su lógica
            // se maneja mejor con el click en el ítem de la lista.
            if (sampleRecipes.isNotEmpty()) {
                val firstRecipe = sampleRecipes[0] // Tomar la primera receta como ejemplo
                val intent = Intent(this, RecipeDetailActivity::class.java)
                intent.putExtra("RECIPE_ID", firstRecipe.id)
                intent.putExtra("RECIPE_NAME", firstRecipe.name)
                startActivity(intent)
            } else {
                // Si no hay recetas, puedes simplemente ir a la actividad de detalle
                // sin datos específicos, o mostrar un mensaje.
                val intent = Intent(this, RecipeDetailActivity::class.java)
                startActivity(intent)
            }
        }
        // --- Fin del botón temporal ---
    }

    private fun loadSampleRecipes() {
        // Aquí es donde crearías o cargarías tu lista de recetas.
        // Por ahora, vamos a crear algunas recetas de ejemplo directamente.
        // En una app real, esto podría venir de una base de datos, una API,
        // o ser filtrado basado en la categoría seleccionada en MainActivity.

        // TODO: Considerar pasar la categoría desde MainActivity y filtrar/cargar recetas acordemente.
        // val categoryName = intent.getStringExtra("CATEGORY_NAME") // Ejemplo de cómo obtenerla

        sampleRecipes.add(
            Recipe(
                id = "1",
                name = "Tostadas Francesas Clásicas",
                category = "Desayunos",
                time = "20 min",
                servings = "2 porciones",
                ingredients = listOf("4 rebanadas de pan", "2 huevos", "1/2 taza de leche", "1 cdta de canela", "Mantequilla"),
                preparationSteps = listOf("Batir huevos, leche y canela.", "Remojar el pan.", "Cocinar en sartén con mantequilla."),
                imageResId = R.drawable.ic_launcher_background // Reemplaza con una imagen real si tienes
            )
        )
        sampleRecipes.add(
            Recipe(
                id = "2",
                name = "Ensalada César con Pollo",
                category = "Almuerzos",
                time = "30 min",
                servings = "1 porción",
                ingredients = listOf("Lechuga romana", "Pechuga de pollo cocida", "Crutones", "Queso parmesano", "Aderezo César"),
                preparationSteps = listOf("Cortar la lechuga y el pollo.", "Mezclar todos los ingredientes.", "Servir inmediatamente."),
                imageResId = R.drawable.ic_launcher_background // Reemplaza con una imagen real
            )
        )
        sampleRecipes.add(
            Recipe(
                id = "3",
                name = "Salmón al Horno con Espárragos",
                category = "Cenas",
                time = "25 min",
                servings = "2 porciones",
                ingredients = listOf("2 filetes de salmón", "1 manojo de espárragos", "Aceite de oliva", "Sal", "Pimienta", "Limón"),
                preparationSteps = listOf("Precalentar horno a 200°C.", "Colocar salmón y espárragos en bandeja.", "Rociar con aceite, salpimentar.", "Hornear por 12-15 min.", "Servir con limón."),
                // imageUrl = "URL_DE_IMAGEN_DE_SALMON" // Si tuvieras una URL
                imageResId = R.drawable.ic_launcher_background // Reemplaza
            )
        )
        // Puedes añadir más recetas aquí
    }
}
